package basePackage;



public class MultiBrowser {
	
	// YES or NO is important
	public static final String Multiple_Browser_YesOrNO = "no";
	public static final String First_Execution_BrowserName = "Edge";
	public static final String Second_Execution_BrowserName = "chrome";
	public static final String Third_Execution_BrowserName = "firefox";
}
